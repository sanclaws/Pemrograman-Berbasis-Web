<?php include '../db.php';
$kodemk = $_GET['kodemk'];
$data = $conn->query("SELECT * FROM matakuliah WHERE kodemk = '$kodemk'")->fetch_assoc();

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $sks = $_POST['jumlah_sks'];
    $conn->query("UPDATE matakuliah SET nama='$nama', jumlah_sks=$sks WHERE kodemk='$kodemk'");
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Mata Kuliah</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Edit Mata Kuliah</h2>
  <form method="POST">
    <input type="text" class="form-control mb-3" value="<?= $kodemk ?>" disabled>
    <input type="text" name="nama" class="form-control mb-3" value="<?= $data['nama'] ?>" required>
    <input type="number" name="jumlah_sks" class="form-control mb-3" value="<?= $data['jumlah_sks'] ?>" required>
    <button type="submit" name="submit" class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </form>
</body>
</html>

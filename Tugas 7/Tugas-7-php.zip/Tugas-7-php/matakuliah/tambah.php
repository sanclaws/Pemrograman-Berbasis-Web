<?php include '../db.php';
if (isset($_POST['submit'])) {
    $kodemk = $_POST['kodemk'];
    $nama = $_POST['nama'];
    $sks = $_POST['jumlah_sks'];
    $conn->query("INSERT INTO matakuliah VALUES ('$kodemk', '$nama', $sks)");
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Tambah Mata Kuliah</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Tambah Mata Kuliah</h2>
  <form method="POST">
    <input type="text" name="kodemk" class="form-control mb-3" placeholder="Kode MK" required>
    <input type="text" name="nama" class="form-control mb-3" placeholder="Nama Mata Kuliah" required>
    <input type="number" name="jumlah_sks" class="form-control mb-3" placeholder="Jumlah SKS" required>
    <button type="submit" name="submit" class="btn btn-success">Simpan</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a
    </form>
</body>
</html>

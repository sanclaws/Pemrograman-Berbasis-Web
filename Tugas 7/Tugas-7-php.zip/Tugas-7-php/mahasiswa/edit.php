<?php include '../db.php';
$npm = $_GET['npm'];
$data = $conn->query("SELECT * FROM mahasiswa WHERE npm = '$npm'")->fetch_assoc();

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $jurusan = $_POST['jurusan'];
    $alamat = $_POST['alamat'];
    $conn->query("UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan', alamat='$alamat' WHERE npm='$npm'");
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Mahasiswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Edit Mahasiswa</h2>
  <form method="POST">
    <input type="text" class="form-control mb-3" value="<?= $npm ?>" disabled>
    <input type="text" name="nama" class="form-control mb-3" value="<?= $data['nama'] ?>" required>
    <select name="jurusan" class="form-select mb-3">
      <option value="Teknik Informatika" <?= $data['jurusan'] == 'Teknik Informatika' ? 'selected' : '' ?>>Teknik Informatika</option>
      <option value="Sistem Operasi" <?= $data['jurusan'] == 'Sistem Operasi' ? 'selected' : '' ?>>Sistem Operasi</option>
    </select>
    <textarea name="alamat" class="form-control mb-3"><?= $data['alamat'] ?></textarea>
    <button type="submit" name="submit" class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </form>
</body>
</html>

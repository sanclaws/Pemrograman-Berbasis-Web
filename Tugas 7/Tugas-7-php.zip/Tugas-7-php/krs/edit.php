<?php include '../db.php';

$id = $_GET['id'];
$data = $conn->query("SELECT * FROM krs WHERE id = $id")->fetch_assoc();

if (isset($_POST['submit'])) {
    $npm = $_POST['npm'];
    $kodemk = $_POST['kodemk'];
    $conn->query("UPDATE krs SET mahasiswa_npm = '$npm', matakuliah_kodemk = '$kodemk' WHERE id = $id");
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit KRS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Edit Data KRS</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Nama Mahasiswa</label>
      <select name="npm" class="form-select">
        <?php
        $mhs = $conn->query("SELECT * FROM mahasiswa");
        while ($row = $mhs->fetch_assoc()) {
          $selected = $data['mahasiswa_npm'] == $row['npm'] ? 'selected' : '';
          echo "<option value='{$row['npm']}' $selected>{$row['nama']}</option>";
        }
        ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Mata Kuliah</label>
      <select name="kodemk" class="form-select">
        <?php
        $mk = $conn->query("SELECT * FROM matakuliah");
        while ($row = $mk->fetch_assoc()) {
          $selected = $data['matakuliah_kodemk'] == $row['kodemk'] ? 'selected' : '';
          echo "<option value='{$row['kodemk']}' $selected>{$row['nama']}</option>";
        }
        ?>
      </select>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </form>
</body>
</html>

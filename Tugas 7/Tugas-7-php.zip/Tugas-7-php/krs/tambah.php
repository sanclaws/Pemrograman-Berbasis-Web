<?php include '../db.php';

if (isset($_POST['submit'])) {
    $npm = $_POST['npm'];
    $kodemk = $_POST['kodemk'];
    $sql = "INSERT INTO krs (mahasiswa_npm, matakuliah_kodemk) VALUES ('$npm', '$kodemk')";
    $conn->query($sql);
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Tambah KRS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Tambah Data KRS</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Nama Mahasiswa</label>
      <select name="npm" class="form-select" required>
        <?php
        $mhs = $conn->query("SELECT * FROM mahasiswa");
        while ($row = $mhs->fetch_assoc()) {
          echo "<option value='{$row['npm']}'>{$row['nama']}</option>";
        }
        ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Mata Kuliah</label>
      <select name="kodemk" class="form-select" required>
        <?php
        $mk = $conn->query("SELECT * FROM matakuliah");
        while ($row = $mk->fetch_assoc()) {
          echo "<option value='{$row['kodemk']}'>{$row['nama']}</option>";
        }
        ?>
      </select>
    </div>
    <button type="submit" name="submit" class="btn btn-success">Simpan</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </form>
</body>
</html>

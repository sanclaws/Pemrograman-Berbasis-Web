<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Data KRS Mahasiswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h2>Data KRS Mahasiswa</h2>
  <a href="tambah.php" class="btn btn-primary mb-3">Tambah KRS</a>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Lengkap</th>
        <th>Mata Kuliah</th>
        <th>Keterangan</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = "SELECT m.nama AS mahasiswa, mk.nama AS matkul, mk.jumlah_sks, k.id
              FROM krs k
              JOIN mahasiswa m ON k.mahasiswa_npm = m.npm
              JOIN matakuliah mk ON k.matakuliah_kodemk = mk.kodemk";
      $result = mysqli_query($conn, $sql);
      $no = 1;
      while ($row = $result->fetch_assoc()) {
          echo "<tr>
                  <td>{$no}</td>
                  <td>" . (isset($row['mahasiswa']) ? $row['mahasiswa'] : '') . "</td>
                  <td>" . (isset($row['matkul']) ? $row['matkul'] : '') . "</td>
                  <td><strong>{$row['mahasiswa']}</strong> Mengambil Mata Kuliah <strong>{$row['matkul']}</strong> ({$row['jumlah_sks']} SKS)</td>
                  <td>
                    <a href='edit.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='hapus.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin?')\">Hapus</a>
                  </td>
                </tr>";
          $no++;
      }
      ?>
    </tbody>
  </table>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Form Rute Penerbangan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="p-4">
  <div class="container">
    <h2 class="mb-4 text-center text-success">Pendaftaran Rute Penerbangan</h2>
    <form method="POST" class="border border-2 p-3 mb-4 rounded">
      <div class="mb-3">
        <label class="form-label fw-bold">Nama Maskapai</label>
        <input type="text" name="maskapai" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label fw-bold">Bandara Asal</label>
        <select name="asal" class="form-select" required>
    <option value="">-- Pilih Bandara Asal --</option>
    <option value="Soekarno-Hatta (CGK)">Soekarno-Hatta (CGK)</option>
    <option value="Juanda (SUB)">Juanda (SUB)</option>
    <option value="Ngurah Rai (DPS)">Ngurah Rai (DPS)</option>
    <option value="Kualanamu (KNO)">Kualanamu (KNO)</option>
    <option value="Sultan Hasanuddin (UPG)">Sultan Hasanuddin (UPG)</option>
    <option value="Halim Perdanakusuma (HLP)">Halim Perdanakusuma (HLP)</option>
    <option value="Jenderal Ahmad Yani">Jenderal Ahmad Yani</option>
  </select>
      </div>
      <div class="mb-3">
        <label class="form-label fw-bold">Bandara Tujuan</label>
        <select name="tujuan" class="form-select" required>
    <option value="">-- Pilih Bandara Tujuan --</option>
    <option value="Soekarno-Hatta (CGK)">Soekarno-Hatta (CGK)</option>
    <option value="Juanda (SUB)">Juanda (SUB)</option>
    <option value="Ngurah Rai (DPS)">Ngurah Rai (DPS)</option>
    <option value="Kualanamu (KNO)">Kualanamu (KNO)</option>
    <option value="Sultan Hasanuddin (UPG)">Sultan Hasanuddin (UPG)</option>
    <option value="Halim Perdanakusuma (HLP)">Halim Perdanakusuma (HLP)</option>
    <option value="Jenderal Ahmad Yani">Jenderal Ahmad Yani</option>
  </select>
      </div>
      <div class="mb-3">
        <label class="form-label fw-bold">Harga Tiket</label>
        <input type="text" name="harga" class="form-control" placeholder="Masukkan harga tanpa titik atau koma" required>
      </div>
      <div class="text-end">
        <button type="submit" name="submit" class="btn btn-success me-2">Pesan</button>
        <button type="reset" class="btn btn-secondary">Reset</button>
      </div>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $maskapai = $_POST['maskapai'];
        $asal = $_POST['asal'];
        $tujuan = $_POST['tujuan'];
        $harga = (int)$_POST['harga'];
        $pajak = $harga * 0.1;
        $total = $harga + $pajak;
        $tanggal = date("d-m-Y");

        echo '
        <div class="container d-flex justify-content-center align-items-center">
        <div class="table-responsive text-center mt-4">
          <h4 class="text-success">Data Rute yang Diproses</h4>
          <table class="table table-bordered table-striped text-center w-auto">
            <thead class="table-light">
              <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nama Maskapai</th>
                <th>Asal</th>
                <th>Tujuan</th>
                <th>Harga Tiket</th>
                <th>Pajak</th>
                <th>Total Harga</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>' . $tanggal . '</td>
                <td>' . $maskapai . '</td>
                <td>' . $asal . '</td>
                <td>' . $tujuan . '</td>
                <td>Rp ' . number_format($harga, 0, ',', '.') . '</td>
                <td>Rp ' . number_format($pajak, 0, ',', '.') . '</td>
                <td>Rp ' . number_format($total, 0, ',', '.') . '</td>
              </tr>
            </tbody>
          </table>
          </div>
        </div>';
    }
    ?>
  </div>
</body>
</html>
